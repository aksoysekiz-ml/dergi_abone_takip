﻿namespace abone_takip2
{
    partial class yönlendirme
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_kisiekle = new System.Windows.Forms.Button();
            this.btn_abone_islemleri = new System.Windows.Forms.Button();
            this.btn_dergitakip = new System.Windows.Forms.Button();
            this.pnl_kasa = new System.Windows.Forms.Panel();
            this.lbl_gelecekpara = new System.Windows.Forms.Label();
            this.lbl_gelenpara = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button_myform = new System.Windows.Forms.Button();
            this.comboBox_kisi = new System.Windows.Forms.ComboBox();
            this.radioButton_tc = new System.Windows.Forms.RadioButton();
            this.groupBox_kisi_edit = new System.Windows.Forms.GroupBox();
            this.txt_isim = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_kisi_edit_close = new System.Windows.Forms.Button();
            this.btn_kisiyi_isimle_bul = new System.Windows.Forms.Button();
            this.btn_duzenlemeye_git = new System.Windows.Forms.Button();
            this.radioButton_numara = new System.Windows.Forms.RadioButton();
            this.flowLayoutPanel_info_kisi_with_isim = new System.Windows.Forms.FlowLayoutPanel();
            this.groupBox_kisi_sec2 = new System.Windows.Forms.GroupBox();
            this.txt_isim2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.btn_isim_ile_bul2 = new System.Windows.Forms.Button();
            this.btn_duzenlemeye_git2 = new System.Windows.Forms.Button();
            this.radioButton_numara2 = new System.Windows.Forms.RadioButton();
            this.radioButton_tc2 = new System.Windows.Forms.RadioButton();
            this.cb_kisi2 = new System.Windows.Forms.ComboBox();
            this.flowLayoutPanel_info_kisi_with_isim2 = new System.Windows.Forms.FlowLayoutPanel();
            this.btn_kisi_edit = new System.Windows.Forms.Button();
            this.pnl_kasa.SuspendLayout();
            this.groupBox_kisi_edit.SuspendLayout();
            this.groupBox_kisi_sec2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_kisiekle
            // 
            this.btn_kisiekle.BackColor = System.Drawing.Color.HotPink;
            this.btn_kisiekle.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_kisiekle.Font = new System.Drawing.Font("Impact", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_kisiekle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btn_kisiekle.Location = new System.Drawing.Point(42, 23);
            this.btn_kisiekle.Name = "btn_kisiekle";
            this.btn_kisiekle.Size = new System.Drawing.Size(319, 227);
            this.btn_kisiekle.TabIndex = 0;
            this.btn_kisiekle.Text = "S i s t e m e     K i ş i       E k l e";
            this.btn_kisiekle.UseVisualStyleBackColor = false;
            this.btn_kisiekle.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_abone_islemleri
            // 
            this.btn_abone_islemleri.BackColor = System.Drawing.Color.PaleVioletRed;
            this.btn_abone_islemleri.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_abone_islemleri.Font = new System.Drawing.Font("Impact", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_abone_islemleri.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btn_abone_islemleri.Location = new System.Drawing.Point(456, 23);
            this.btn_abone_islemleri.Name = "btn_abone_islemleri";
            this.btn_abone_islemleri.Size = new System.Drawing.Size(309, 227);
            this.btn_abone_islemleri.TabIndex = 4;
            this.btn_abone_islemleri.Text = "A b o n e\nİ ş l e m l e r i";
            this.btn_abone_islemleri.UseVisualStyleBackColor = false;
            this.btn_abone_islemleri.Click += new System.EventHandler(this.btn_abone_islemleri_Click);
            // 
            // btn_dergitakip
            // 
            this.btn_dergitakip.BackColor = System.Drawing.Color.Pink;
            this.btn_dergitakip.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_dergitakip.Font = new System.Drawing.Font("Impact", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_dergitakip.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btn_dergitakip.Location = new System.Drawing.Point(42, 340);
            this.btn_dergitakip.Name = "btn_dergitakip";
            this.btn_dergitakip.Size = new System.Drawing.Size(319, 215);
            this.btn_dergitakip.TabIndex = 5;
            this.btn_dergitakip.Text = "D e r g i    T a k i p";
            this.btn_dergitakip.UseVisualStyleBackColor = false;
            this.btn_dergitakip.Click += new System.EventHandler(this.btn_dergitakip_Click);
            // 
            // pnl_kasa
            // 
            this.pnl_kasa.BackColor = System.Drawing.Color.LavenderBlush;
            this.pnl_kasa.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnl_kasa.Controls.Add(this.lbl_gelecekpara);
            this.pnl_kasa.Controls.Add(this.lbl_gelenpara);
            this.pnl_kasa.Controls.Add(this.label2);
            this.pnl_kasa.Controls.Add(this.label1);
            this.pnl_kasa.Location = new System.Drawing.Point(456, 340);
            this.pnl_kasa.Name = "pnl_kasa";
            this.pnl_kasa.Size = new System.Drawing.Size(309, 215);
            this.pnl_kasa.TabIndex = 6;
            // 
            // lbl_gelecekpara
            // 
            this.lbl_gelecekpara.AutoSize = true;
            this.lbl_gelecekpara.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lbl_gelecekpara.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_gelecekpara.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lbl_gelecekpara.Location = new System.Drawing.Point(191, 139);
            this.lbl_gelecekpara.Name = "lbl_gelecekpara";
            this.lbl_gelecekpara.Size = new System.Drawing.Size(18, 20);
            this.lbl_gelecekpara.TabIndex = 3;
            this.lbl_gelecekpara.Text = "0";
            // 
            // lbl_gelenpara
            // 
            this.lbl_gelenpara.AutoSize = true;
            this.lbl_gelenpara.BackColor = System.Drawing.Color.OrangeRed;
            this.lbl_gelenpara.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_gelenpara.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lbl_gelenpara.Location = new System.Drawing.Point(174, 60);
            this.lbl_gelenpara.Name = "lbl_gelenpara";
            this.lbl_gelenpara.Size = new System.Drawing.Size(18, 20);
            this.lbl_gelenpara.TabIndex = 2;
            this.lbl_gelenpara.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Gray;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label2.Location = new System.Drawing.Point(49, 139);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(136, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "GELECEK PARA : ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Silver;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label1.Location = new System.Drawing.Point(49, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "GELEN PARA : ";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button1.Cursor = System.Windows.Forms.Cursors.No;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button1.Location = new System.Drawing.Point(785, 6);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(46, 41);
            this.button1.TabIndex = 7;
            this.button1.Text = "X";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // button_myform
            // 
            this.button_myform.BackColor = System.Drawing.Color.Black;
            this.button_myform.Location = new System.Drawing.Point(785, 53);
            this.button_myform.Name = "button_myform";
            this.button_myform.Size = new System.Drawing.Size(46, 502);
            this.button_myform.TabIndex = 8;
            this.button_myform.Text = "button2";
            this.button_myform.UseVisualStyleBackColor = false;
            this.button_myform.Visible = false;
            this.button_myform.Click += new System.EventHandler(this.button2_Click);
            // 
            // comboBox_kisi
            // 
            this.comboBox_kisi.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.comboBox_kisi.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBox_kisi.FormattingEnabled = true;
            this.comboBox_kisi.Location = new System.Drawing.Point(19, 42);
            this.comboBox_kisi.Name = "comboBox_kisi";
            this.comboBox_kisi.Size = new System.Drawing.Size(131, 21);
            this.comboBox_kisi.TabIndex = 14;
            // 
            // radioButton_tc
            // 
            this.radioButton_tc.AutoSize = true;
            this.radioButton_tc.Location = new System.Drawing.Point(27, 19);
            this.radioButton_tc.Name = "radioButton_tc";
            this.radioButton_tc.Size = new System.Drawing.Size(38, 17);
            this.radioButton_tc.TabIndex = 15;
            this.radioButton_tc.TabStop = true;
            this.radioButton_tc.Text = "Tc";
            this.radioButton_tc.UseVisualStyleBackColor = true;
            this.radioButton_tc.CheckedChanged += new System.EventHandler(this.radioButton_tc_CheckedChanged);
            // 
            // groupBox_kisi_edit
            // 
            this.groupBox_kisi_edit.Controls.Add(this.txt_isim);
            this.groupBox_kisi_edit.Controls.Add(this.label3);
            this.groupBox_kisi_edit.Controls.Add(this.btn_kisi_edit_close);
            this.groupBox_kisi_edit.Controls.Add(this.btn_kisiyi_isimle_bul);
            this.groupBox_kisi_edit.Controls.Add(this.btn_duzenlemeye_git);
            this.groupBox_kisi_edit.Controls.Add(this.radioButton_numara);
            this.groupBox_kisi_edit.Controls.Add(this.radioButton_tc);
            this.groupBox_kisi_edit.Controls.Add(this.comboBox_kisi);
            this.groupBox_kisi_edit.Location = new System.Drawing.Point(57, 64);
            this.groupBox_kisi_edit.Name = "groupBox_kisi_edit";
            this.groupBox_kisi_edit.Size = new System.Drawing.Size(287, 149);
            this.groupBox_kisi_edit.TabIndex = 16;
            this.groupBox_kisi_edit.TabStop = false;
            this.groupBox_kisi_edit.Text = "Kişi Seç";
            this.groupBox_kisi_edit.Visible = false;
            // 
            // txt_isim
            // 
            this.txt_isim.Location = new System.Drawing.Point(38, 100);
            this.txt_isim.Name = "txt_isim";
            this.txt_isim.Size = new System.Drawing.Size(212, 20);
            this.txt_isim.TabIndex = 21;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(67, 84);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(158, 13);
            this.label3.TabIndex = 20;
            this.label3.Text = "* TC veya Numara Bilmiyorum... ";
            // 
            // btn_kisi_edit_close
            // 
            this.btn_kisi_edit_close.Location = new System.Drawing.Point(249, 0);
            this.btn_kisi_edit_close.Name = "btn_kisi_edit_close";
            this.btn_kisi_edit_close.Size = new System.Drawing.Size(38, 27);
            this.btn_kisi_edit_close.TabIndex = 19;
            this.btn_kisi_edit_close.Text = "X";
            this.btn_kisi_edit_close.UseVisualStyleBackColor = true;
            this.btn_kisi_edit_close.Click += new System.EventHandler(this.btn_kisi_edit_close_Click);
            // 
            // btn_kisiyi_isimle_bul
            // 
            this.btn_kisiyi_isimle_bul.Location = new System.Drawing.Point(0, 123);
            this.btn_kisiyi_isimle_bul.Name = "btn_kisiyi_isimle_bul";
            this.btn_kisiyi_isimle_bul.Size = new System.Drawing.Size(287, 26);
            this.btn_kisiyi_isimle_bul.TabIndex = 18;
            this.btn_kisiyi_isimle_bul.Text = "İsim İle Bul";
            this.btn_kisiyi_isimle_bul.UseVisualStyleBackColor = true;
            this.btn_kisiyi_isimle_bul.Click += new System.EventHandler(this.btn_kisiyi_isimle_bul_Click);
            // 
            // btn_duzenlemeye_git
            // 
            this.btn_duzenlemeye_git.Location = new System.Drawing.Point(167, 38);
            this.btn_duzenlemeye_git.Name = "btn_duzenlemeye_git";
            this.btn_duzenlemeye_git.Size = new System.Drawing.Size(102, 26);
            this.btn_duzenlemeye_git.TabIndex = 17;
            this.btn_duzenlemeye_git.Text = "Düzenlemeye Git";
            this.btn_duzenlemeye_git.UseVisualStyleBackColor = true;
            this.btn_duzenlemeye_git.Click += new System.EventHandler(this.btn_duzenlemeye_git_Click);
            // 
            // radioButton_numara
            // 
            this.radioButton_numara.AutoSize = true;
            this.radioButton_numara.Location = new System.Drawing.Point(176, 19);
            this.radioButton_numara.Name = "radioButton_numara";
            this.radioButton_numara.Size = new System.Drawing.Size(62, 17);
            this.radioButton_numara.TabIndex = 16;
            this.radioButton_numara.TabStop = true;
            this.radioButton_numara.Text = "Numara";
            this.radioButton_numara.UseVisualStyleBackColor = true;
            this.radioButton_numara.CheckedChanged += new System.EventHandler(this.radioButton_numara_CheckedChanged);
            // 
            // flowLayoutPanel_info_kisi_with_isim
            // 
            this.flowLayoutPanel_info_kisi_with_isim.Location = new System.Drawing.Point(34, 44);
            this.flowLayoutPanel_info_kisi_with_isim.Name = "flowLayoutPanel_info_kisi_with_isim";
            this.flowLayoutPanel_info_kisi_with_isim.Size = new System.Drawing.Size(327, 235);
            this.flowLayoutPanel_info_kisi_with_isim.TabIndex = 17;
            this.flowLayoutPanel_info_kisi_with_isim.Visible = false;
            // 
            // groupBox_kisi_sec2
            // 
            this.groupBox_kisi_sec2.Controls.Add(this.txt_isim2);
            this.groupBox_kisi_sec2.Controls.Add(this.label4);
            this.groupBox_kisi_sec2.Controls.Add(this.button3);
            this.groupBox_kisi_sec2.Controls.Add(this.btn_isim_ile_bul2);
            this.groupBox_kisi_sec2.Controls.Add(this.btn_duzenlemeye_git2);
            this.groupBox_kisi_sec2.Controls.Add(this.radioButton_numara2);
            this.groupBox_kisi_sec2.Controls.Add(this.radioButton_tc2);
            this.groupBox_kisi_sec2.Controls.Add(this.cb_kisi2);
            this.groupBox_kisi_sec2.Location = new System.Drawing.Point(468, 64);
            this.groupBox_kisi_sec2.Name = "groupBox_kisi_sec2";
            this.groupBox_kisi_sec2.Size = new System.Drawing.Size(287, 149);
            this.groupBox_kisi_sec2.TabIndex = 18;
            this.groupBox_kisi_sec2.TabStop = false;
            this.groupBox_kisi_sec2.Text = "Kişi Seç";
            this.groupBox_kisi_sec2.Visible = false;
            // 
            // txt_isim2
            // 
            this.txt_isim2.Location = new System.Drawing.Point(38, 100);
            this.txt_isim2.Name = "txt_isim2";
            this.txt_isim2.Size = new System.Drawing.Size(212, 20);
            this.txt_isim2.TabIndex = 21;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(67, 84);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(158, 13);
            this.label4.TabIndex = 20;
            this.label4.Text = "* TC veya Numara Bilmiyorum... ";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(249, 0);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(38, 27);
            this.button3.TabIndex = 19;
            this.button3.Text = "X";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // btn_isim_ile_bul2
            // 
            this.btn_isim_ile_bul2.Location = new System.Drawing.Point(0, 123);
            this.btn_isim_ile_bul2.Name = "btn_isim_ile_bul2";
            this.btn_isim_ile_bul2.Size = new System.Drawing.Size(287, 26);
            this.btn_isim_ile_bul2.TabIndex = 18;
            this.btn_isim_ile_bul2.Text = "İsim İle Bul";
            this.btn_isim_ile_bul2.UseVisualStyleBackColor = true;
            this.btn_isim_ile_bul2.Click += new System.EventHandler(this.btn_isim_ile_bul2_Click);
            // 
            // btn_duzenlemeye_git2
            // 
            this.btn_duzenlemeye_git2.Location = new System.Drawing.Point(167, 38);
            this.btn_duzenlemeye_git2.Name = "btn_duzenlemeye_git2";
            this.btn_duzenlemeye_git2.Size = new System.Drawing.Size(102, 26);
            this.btn_duzenlemeye_git2.TabIndex = 17;
            this.btn_duzenlemeye_git2.Text = "Düzenlemeye Git";
            this.btn_duzenlemeye_git2.UseVisualStyleBackColor = true;
            this.btn_duzenlemeye_git2.Click += new System.EventHandler(this.btn_duzenlemeye_git2_Click);
            // 
            // radioButton_numara2
            // 
            this.radioButton_numara2.AutoSize = true;
            this.radioButton_numara2.Location = new System.Drawing.Point(176, 19);
            this.radioButton_numara2.Name = "radioButton_numara2";
            this.radioButton_numara2.Size = new System.Drawing.Size(62, 17);
            this.radioButton_numara2.TabIndex = 16;
            this.radioButton_numara2.TabStop = true;
            this.radioButton_numara2.Text = "Numara";
            this.radioButton_numara2.UseVisualStyleBackColor = true;
            this.radioButton_numara2.CheckedChanged += new System.EventHandler(this.radioButton_numara2_CheckedChanged);
            // 
            // radioButton_tc2
            // 
            this.radioButton_tc2.AutoSize = true;
            this.radioButton_tc2.Location = new System.Drawing.Point(27, 19);
            this.radioButton_tc2.Name = "radioButton_tc2";
            this.radioButton_tc2.Size = new System.Drawing.Size(38, 17);
            this.radioButton_tc2.TabIndex = 15;
            this.radioButton_tc2.TabStop = true;
            this.radioButton_tc2.Text = "Tc";
            this.radioButton_tc2.UseVisualStyleBackColor = true;
            this.radioButton_tc2.CheckedChanged += new System.EventHandler(this.radioButton_tc2_CheckedChanged);
            // 
            // cb_kisi2
            // 
            this.cb_kisi2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cb_kisi2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cb_kisi2.FormattingEnabled = true;
            this.cb_kisi2.Location = new System.Drawing.Point(19, 42);
            this.cb_kisi2.Name = "cb_kisi2";
            this.cb_kisi2.Size = new System.Drawing.Size(131, 21);
            this.cb_kisi2.TabIndex = 14;
            // 
            // flowLayoutPanel_info_kisi_with_isim2
            // 
            this.flowLayoutPanel_info_kisi_with_isim2.Location = new System.Drawing.Point(456, 23);
            this.flowLayoutPanel_info_kisi_with_isim2.Name = "flowLayoutPanel_info_kisi_with_isim2";
            this.flowLayoutPanel_info_kisi_with_isim2.Size = new System.Drawing.Size(319, 227);
            this.flowLayoutPanel_info_kisi_with_isim2.TabIndex = 19;
            this.flowLayoutPanel_info_kisi_with_isim2.Visible = false;
            // 
            // btn_kisi_edit
            // 
            this.btn_kisi_edit.BackColor = System.Drawing.Color.HotPink;
            this.btn_kisi_edit.BackgroundImage = global::abone_takip2.Properties.Resources.edit_ksisi;
            this.btn_kisi_edit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_kisi_edit.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_kisi_edit.FlatAppearance.BorderSize = 0;
            this.btn_kisi_edit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_kisi_edit.Location = new System.Drawing.Point(306, 200);
            this.btn_kisi_edit.Name = "btn_kisi_edit";
            this.btn_kisi_edit.Size = new System.Drawing.Size(46, 41);
            this.btn_kisi_edit.TabIndex = 9;
            this.btn_kisi_edit.Text = "xxx";
            this.btn_kisi_edit.UseVisualStyleBackColor = false;
            this.btn_kisi_edit.Click += new System.EventHandler(this.btn_kisi_edit_Click);
            // 
            // yönlendirme
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(845, 579);
            this.Controls.Add(this.flowLayoutPanel_info_kisi_with_isim2);
            this.Controls.Add(this.groupBox_kisi_sec2);
            this.Controls.Add(this.groupBox_kisi_edit);
            this.Controls.Add(this.flowLayoutPanel_info_kisi_with_isim);
            this.Controls.Add(this.btn_kisi_edit);
            this.Controls.Add(this.button_myform);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pnl_kasa);
            this.Controls.Add(this.btn_dergitakip);
            this.Controls.Add(this.btn_abone_islemleri);
            this.Controls.Add(this.btn_kisiekle);
            this.Cursor = System.Windows.Forms.Cursors.Cross;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "yönlendirme";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "yönlendirme";
            this.Load += new System.EventHandler(this.yönlendirme_Load);
            this.pnl_kasa.ResumeLayout(false);
            this.pnl_kasa.PerformLayout();
            this.groupBox_kisi_edit.ResumeLayout(false);
            this.groupBox_kisi_edit.PerformLayout();
            this.groupBox_kisi_sec2.ResumeLayout(false);
            this.groupBox_kisi_sec2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_kisiekle;
        private System.Windows.Forms.Button btn_abone_islemleri;
        private System.Windows.Forms.Button btn_dergitakip;
        private System.Windows.Forms.Panel pnl_kasa;
        private System.Windows.Forms.Label lbl_gelecekpara;
        private System.Windows.Forms.Label lbl_gelenpara;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button_myform;
        private System.Windows.Forms.Button btn_kisi_edit;
        private System.Windows.Forms.ComboBox comboBox_kisi;
        private System.Windows.Forms.RadioButton radioButton_tc;
        private System.Windows.Forms.GroupBox groupBox_kisi_edit;
        private System.Windows.Forms.Button btn_kisi_edit_close;
        private System.Windows.Forms.Button btn_kisiyi_isimle_bul;
        private System.Windows.Forms.Button btn_duzenlemeye_git;
        private System.Windows.Forms.RadioButton radioButton_numara;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel_info_kisi_with_isim;
        private System.Windows.Forms.TextBox txt_isim;
        private System.Windows.Forms.GroupBox groupBox_kisi_sec2;
        private System.Windows.Forms.TextBox txt_isim2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button btn_isim_ile_bul2;
        private System.Windows.Forms.Button btn_duzenlemeye_git2;
        private System.Windows.Forms.RadioButton radioButton_numara2;
        private System.Windows.Forms.RadioButton radioButton_tc2;
        private System.Windows.Forms.ComboBox cb_kisi2;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel_info_kisi_with_isim2;
    }
}
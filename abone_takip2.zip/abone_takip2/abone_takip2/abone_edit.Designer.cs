﻿namespace abone_takip2
{
    partial class abone_edit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_sayi6 = new System.Windows.Forms.Label();
            this.label_sayi5 = new System.Windows.Forms.Label();
            this.label_sayi4 = new System.Windows.Forms.Label();
            this.label_sayi3 = new System.Windows.Forms.Label();
            this.label_sayi2 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label_sayi1 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.checkBox_odendi_sayi6 = new System.Windows.Forms.CheckBox();
            this.txt_fiyat_sayi6 = new System.Windows.Forms.TextBox();
            this.txt_miktar_sayi6 = new System.Windows.Forms.TextBox();
            this.checkBox_teslimedildi_sayi6 = new System.Windows.Forms.CheckBox();
            this.checkBox_odendi_sayi5 = new System.Windows.Forms.CheckBox();
            this.txt_fiyat_sayi5 = new System.Windows.Forms.TextBox();
            this.txt_miktar_sayi5 = new System.Windows.Forms.TextBox();
            this.checkBox_teslimedildi_sayi5 = new System.Windows.Forms.CheckBox();
            this.checkBox_odendi_sayi4 = new System.Windows.Forms.CheckBox();
            this.txt_fiyat_sayi4 = new System.Windows.Forms.TextBox();
            this.txt_miktar_sayi4 = new System.Windows.Forms.TextBox();
            this.checkBox_teslimedildi_sayi4 = new System.Windows.Forms.CheckBox();
            this.checkBox_odendi_sayi3 = new System.Windows.Forms.CheckBox();
            this.txt_fiyat_sayi3 = new System.Windows.Forms.TextBox();
            this.txt_miktar_sayi3 = new System.Windows.Forms.TextBox();
            this.checkBox_teslimedildi_sayi3 = new System.Windows.Forms.CheckBox();
            this.checkBox_odendi_sayi2 = new System.Windows.Forms.CheckBox();
            this.txt_fiyat_sayi2 = new System.Windows.Forms.TextBox();
            this.txt_miktar_sayi2 = new System.Windows.Forms.TextBox();
            this.checkBox_teslimedildi_sayi2 = new System.Windows.Forms.CheckBox();
            this.checkBox_odendi_sayi1 = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_fiyat_sayi1 = new System.Windows.Forms.TextBox();
            this.txt_miktar_sayi1 = new System.Windows.Forms.TextBox();
            this.checkBox_teslimedildi_sayi1 = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tumunu_teslim_et = new System.Windows.Forms.Button();
            this.tumunu_ode = new System.Windows.Forms.Button();
            this.btn_tamamla = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label_sayi6
            // 
            this.label_sayi6.AutoSize = true;
            this.label_sayi6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label_sayi6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_sayi6.Location = new System.Drawing.Point(342, 167);
            this.label_sayi6.Name = "label_sayi6";
            this.label_sayi6.Size = new System.Drawing.Size(62, 22);
            this.label_sayi6.TabIndex = 110;
            this.label_sayi6.Text = "label19";
            this.label_sayi6.Click += new System.EventHandler(this.label_sayi6_Click);
            // 
            // label_sayi5
            // 
            this.label_sayi5.AutoSize = true;
            this.label_sayi5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label_sayi5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_sayi5.Location = new System.Drawing.Point(342, 121);
            this.label_sayi5.Name = "label_sayi5";
            this.label_sayi5.Size = new System.Drawing.Size(62, 22);
            this.label_sayi5.TabIndex = 109;
            this.label_sayi5.Text = "label18";
            this.label_sayi5.Click += new System.EventHandler(this.label_sayi5_Click);
            // 
            // label_sayi4
            // 
            this.label_sayi4.AutoSize = true;
            this.label_sayi4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label_sayi4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_sayi4.Location = new System.Drawing.Point(342, 73);
            this.label_sayi4.Name = "label_sayi4";
            this.label_sayi4.Size = new System.Drawing.Size(62, 22);
            this.label_sayi4.TabIndex = 108;
            this.label_sayi4.Text = "label17";
            this.label_sayi4.Click += new System.EventHandler(this.label_sayi4_Click);
            // 
            // label_sayi3
            // 
            this.label_sayi3.AutoSize = true;
            this.label_sayi3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label_sayi3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_sayi3.Location = new System.Drawing.Point(21, 165);
            this.label_sayi3.Name = "label_sayi3";
            this.label_sayi3.Size = new System.Drawing.Size(62, 22);
            this.label_sayi3.TabIndex = 107;
            this.label_sayi3.Text = "label16";
            this.label_sayi3.Click += new System.EventHandler(this.label_sayi3_Click);
            // 
            // label_sayi2
            // 
            this.label_sayi2.AutoSize = true;
            this.label_sayi2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label_sayi2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_sayi2.Location = new System.Drawing.Point(21, 118);
            this.label_sayi2.Name = "label_sayi2";
            this.label_sayi2.Size = new System.Drawing.Size(62, 22);
            this.label_sayi2.TabIndex = 106;
            this.label_sayi2.Text = "label15";
            this.label_sayi2.Click += new System.EventHandler(this.label_sayi2_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(462, 329);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(13, 13);
            this.label14.TabIndex = 105;
            this.label14.Text = "0";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(364, 329);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(92, 13);
            this.label13.TabIndex = 104;
            this.label13.Text = "Satış Yapan Kişi : ";
            // 
            // label_sayi1
            // 
            this.label_sayi1.AutoSize = true;
            this.label_sayi1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label_sayi1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_sayi1.Location = new System.Drawing.Point(21, 73);
            this.label_sayi1.Name = "label_sayi1";
            this.label_sayi1.Size = new System.Drawing.Size(62, 22);
            this.label_sayi1.TabIndex = 103;
            this.label_sayi1.Text = "label12";
            this.label_sayi1.Click += new System.EventHandler(this.label_sayi1_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(321, 152);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(274, 13);
            this.label11.TabIndex = 102;
            this.label11.Text = "---------------------------------------------------------------------------------" +
    "--------";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(321, 99);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(274, 13);
            this.label10.TabIndex = 101;
            this.label10.Text = "---------------------------------------------------------------------------------" +
    "--------";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(0, 191);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(274, 13);
            this.label9.TabIndex = 100;
            this.label9.Text = "---------------------------------------------------------------------------------" +
    "--------";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(0, 144);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(274, 13);
            this.label8.TabIndex = 99;
            this.label8.Text = "---------------------------------------------------------------------------------" +
    "--------";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(0, 97);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(274, 13);
            this.label7.TabIndex = 98;
            this.label7.Text = "---------------------------------------------------------------------------------" +
    "--------";
            // 
            // checkBox_odendi_sayi6
            // 
            this.checkBox_odendi_sayi6.AutoSize = true;
            this.checkBox_odendi_sayi6.Location = new System.Drawing.Point(578, 171);
            this.checkBox_odendi_sayi6.Name = "checkBox_odendi_sayi6";
            this.checkBox_odendi_sayi6.Size = new System.Drawing.Size(29, 17);
            this.checkBox_odendi_sayi6.TabIndex = 97;
            this.checkBox_odendi_sayi6.Text = " ";
            this.checkBox_odendi_sayi6.UseVisualStyleBackColor = true;
            // 
            // txt_fiyat_sayi6
            // 
            this.txt_fiyat_sayi6.Location = new System.Drawing.Point(527, 169);
            this.txt_fiyat_sayi6.Name = "txt_fiyat_sayi6";
            this.txt_fiyat_sayi6.Size = new System.Drawing.Size(50, 20);
            this.txt_fiyat_sayi6.TabIndex = 96;
            // 
            // txt_miktar_sayi6
            // 
            this.txt_miktar_sayi6.Location = new System.Drawing.Point(441, 168);
            this.txt_miktar_sayi6.Name = "txt_miktar_sayi6";
            this.txt_miktar_sayi6.Size = new System.Drawing.Size(45, 20);
            this.txt_miktar_sayi6.TabIndex = 95;
            // 
            // checkBox_teslimedildi_sayi6
            // 
            this.checkBox_teslimedildi_sayi6.AutoSize = true;
            this.checkBox_teslimedildi_sayi6.Location = new System.Drawing.Point(487, 171);
            this.checkBox_teslimedildi_sayi6.Name = "checkBox_teslimedildi_sayi6";
            this.checkBox_teslimedildi_sayi6.Size = new System.Drawing.Size(29, 17);
            this.checkBox_teslimedildi_sayi6.TabIndex = 94;
            this.checkBox_teslimedildi_sayi6.Text = " ";
            this.checkBox_teslimedildi_sayi6.UseVisualStyleBackColor = true;
            // 
            // checkBox_odendi_sayi5
            // 
            this.checkBox_odendi_sayi5.AutoSize = true;
            this.checkBox_odendi_sayi5.Location = new System.Drawing.Point(578, 126);
            this.checkBox_odendi_sayi5.Name = "checkBox_odendi_sayi5";
            this.checkBox_odendi_sayi5.Size = new System.Drawing.Size(29, 17);
            this.checkBox_odendi_sayi5.TabIndex = 93;
            this.checkBox_odendi_sayi5.Text = " ";
            this.checkBox_odendi_sayi5.UseVisualStyleBackColor = true;
            // 
            // txt_fiyat_sayi5
            // 
            this.txt_fiyat_sayi5.Location = new System.Drawing.Point(527, 124);
            this.txt_fiyat_sayi5.Name = "txt_fiyat_sayi5";
            this.txt_fiyat_sayi5.Size = new System.Drawing.Size(50, 20);
            this.txt_fiyat_sayi5.TabIndex = 92;
            // 
            // txt_miktar_sayi5
            // 
            this.txt_miktar_sayi5.Location = new System.Drawing.Point(441, 123);
            this.txt_miktar_sayi5.Name = "txt_miktar_sayi5";
            this.txt_miktar_sayi5.Size = new System.Drawing.Size(45, 20);
            this.txt_miktar_sayi5.TabIndex = 91;
            // 
            // checkBox_teslimedildi_sayi5
            // 
            this.checkBox_teslimedildi_sayi5.AutoSize = true;
            this.checkBox_teslimedildi_sayi5.Location = new System.Drawing.Point(487, 126);
            this.checkBox_teslimedildi_sayi5.Name = "checkBox_teslimedildi_sayi5";
            this.checkBox_teslimedildi_sayi5.Size = new System.Drawing.Size(29, 17);
            this.checkBox_teslimedildi_sayi5.TabIndex = 90;
            this.checkBox_teslimedildi_sayi5.Text = " ";
            this.checkBox_teslimedildi_sayi5.UseVisualStyleBackColor = true;
            // 
            // checkBox_odendi_sayi4
            // 
            this.checkBox_odendi_sayi4.AutoSize = true;
            this.checkBox_odendi_sayi4.Location = new System.Drawing.Point(578, 78);
            this.checkBox_odendi_sayi4.Name = "checkBox_odendi_sayi4";
            this.checkBox_odendi_sayi4.Size = new System.Drawing.Size(29, 17);
            this.checkBox_odendi_sayi4.TabIndex = 89;
            this.checkBox_odendi_sayi4.Text = " ";
            this.checkBox_odendi_sayi4.UseVisualStyleBackColor = true;
            // 
            // txt_fiyat_sayi4
            // 
            this.txt_fiyat_sayi4.Location = new System.Drawing.Point(527, 76);
            this.txt_fiyat_sayi4.Name = "txt_fiyat_sayi4";
            this.txt_fiyat_sayi4.Size = new System.Drawing.Size(50, 20);
            this.txt_fiyat_sayi4.TabIndex = 88;
            // 
            // txt_miktar_sayi4
            // 
            this.txt_miktar_sayi4.Location = new System.Drawing.Point(441, 75);
            this.txt_miktar_sayi4.Name = "txt_miktar_sayi4";
            this.txt_miktar_sayi4.Size = new System.Drawing.Size(45, 20);
            this.txt_miktar_sayi4.TabIndex = 87;
            // 
            // checkBox_teslimedildi_sayi4
            // 
            this.checkBox_teslimedildi_sayi4.AutoSize = true;
            this.checkBox_teslimedildi_sayi4.Location = new System.Drawing.Point(487, 78);
            this.checkBox_teslimedildi_sayi4.Name = "checkBox_teslimedildi_sayi4";
            this.checkBox_teslimedildi_sayi4.Size = new System.Drawing.Size(29, 17);
            this.checkBox_teslimedildi_sayi4.TabIndex = 86;
            this.checkBox_teslimedildi_sayi4.Text = " ";
            this.checkBox_teslimedildi_sayi4.UseVisualStyleBackColor = true;
            // 
            // checkBox_odendi_sayi3
            // 
            this.checkBox_odendi_sayi3.AutoSize = true;
            this.checkBox_odendi_sayi3.Location = new System.Drawing.Point(257, 170);
            this.checkBox_odendi_sayi3.Name = "checkBox_odendi_sayi3";
            this.checkBox_odendi_sayi3.Size = new System.Drawing.Size(29, 17);
            this.checkBox_odendi_sayi3.TabIndex = 85;
            this.checkBox_odendi_sayi3.Text = " ";
            this.checkBox_odendi_sayi3.UseVisualStyleBackColor = true;
            // 
            // txt_fiyat_sayi3
            // 
            this.txt_fiyat_sayi3.Location = new System.Drawing.Point(206, 168);
            this.txt_fiyat_sayi3.Name = "txt_fiyat_sayi3";
            this.txt_fiyat_sayi3.Size = new System.Drawing.Size(50, 20);
            this.txt_fiyat_sayi3.TabIndex = 84;
            // 
            // txt_miktar_sayi3
            // 
            this.txt_miktar_sayi3.Location = new System.Drawing.Point(120, 167);
            this.txt_miktar_sayi3.Name = "txt_miktar_sayi3";
            this.txt_miktar_sayi3.Size = new System.Drawing.Size(45, 20);
            this.txt_miktar_sayi3.TabIndex = 83;
            // 
            // checkBox_teslimedildi_sayi3
            // 
            this.checkBox_teslimedildi_sayi3.AutoSize = true;
            this.checkBox_teslimedildi_sayi3.Location = new System.Drawing.Point(166, 170);
            this.checkBox_teslimedildi_sayi3.Name = "checkBox_teslimedildi_sayi3";
            this.checkBox_teslimedildi_sayi3.Size = new System.Drawing.Size(29, 17);
            this.checkBox_teslimedildi_sayi3.TabIndex = 82;
            this.checkBox_teslimedildi_sayi3.Text = " ";
            this.checkBox_teslimedildi_sayi3.UseVisualStyleBackColor = true;
            // 
            // checkBox_odendi_sayi2
            // 
            this.checkBox_odendi_sayi2.AutoSize = true;
            this.checkBox_odendi_sayi2.Location = new System.Drawing.Point(257, 123);
            this.checkBox_odendi_sayi2.Name = "checkBox_odendi_sayi2";
            this.checkBox_odendi_sayi2.Size = new System.Drawing.Size(29, 17);
            this.checkBox_odendi_sayi2.TabIndex = 81;
            this.checkBox_odendi_sayi2.Text = " ";
            this.checkBox_odendi_sayi2.UseVisualStyleBackColor = true;
            // 
            // txt_fiyat_sayi2
            // 
            this.txt_fiyat_sayi2.Location = new System.Drawing.Point(206, 121);
            this.txt_fiyat_sayi2.Name = "txt_fiyat_sayi2";
            this.txt_fiyat_sayi2.Size = new System.Drawing.Size(50, 20);
            this.txt_fiyat_sayi2.TabIndex = 80;
            // 
            // txt_miktar_sayi2
            // 
            this.txt_miktar_sayi2.Location = new System.Drawing.Point(120, 120);
            this.txt_miktar_sayi2.Name = "txt_miktar_sayi2";
            this.txt_miktar_sayi2.Size = new System.Drawing.Size(45, 20);
            this.txt_miktar_sayi2.TabIndex = 79;
            // 
            // checkBox_teslimedildi_sayi2
            // 
            this.checkBox_teslimedildi_sayi2.AutoSize = true;
            this.checkBox_teslimedildi_sayi2.Location = new System.Drawing.Point(166, 123);
            this.checkBox_teslimedildi_sayi2.Name = "checkBox_teslimedildi_sayi2";
            this.checkBox_teslimedildi_sayi2.Size = new System.Drawing.Size(29, 17);
            this.checkBox_teslimedildi_sayi2.TabIndex = 78;
            this.checkBox_teslimedildi_sayi2.Text = " ";
            this.checkBox_teslimedildi_sayi2.UseVisualStyleBackColor = true;
            // 
            // checkBox_odendi_sayi1
            // 
            this.checkBox_odendi_sayi1.AutoSize = true;
            this.checkBox_odendi_sayi1.Location = new System.Drawing.Point(257, 78);
            this.checkBox_odendi_sayi1.Name = "checkBox_odendi_sayi1";
            this.checkBox_odendi_sayi1.Size = new System.Drawing.Size(29, 17);
            this.checkBox_odendi_sayi1.TabIndex = 77;
            this.checkBox_odendi_sayi1.Text = " ";
            this.checkBox_odendi_sayi1.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(225, 47);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(26, 13);
            this.label6.TabIndex = 75;
            this.label6.Text = "fiyat";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(119, 47);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 13);
            this.label5.TabIndex = 74;
            this.label5.Text = "kactane";
            // 
            // txt_fiyat_sayi1
            // 
            this.txt_fiyat_sayi1.Location = new System.Drawing.Point(206, 76);
            this.txt_fiyat_sayi1.Name = "txt_fiyat_sayi1";
            this.txt_fiyat_sayi1.Size = new System.Drawing.Size(50, 20);
            this.txt_fiyat_sayi1.TabIndex = 73;
            // 
            // txt_miktar_sayi1
            // 
            this.txt_miktar_sayi1.Location = new System.Drawing.Point(120, 75);
            this.txt_miktar_sayi1.Name = "txt_miktar_sayi1";
            this.txt_miktar_sayi1.Size = new System.Drawing.Size(45, 20);
            this.txt_miktar_sayi1.TabIndex = 72;
            // 
            // checkBox_teslimedildi_sayi1
            // 
            this.checkBox_teslimedildi_sayi1.AutoSize = true;
            this.checkBox_teslimedildi_sayi1.Location = new System.Drawing.Point(166, 78);
            this.checkBox_teslimedildi_sayi1.Name = "checkBox_teslimedildi_sayi1";
            this.checkBox_teslimedildi_sayi1.Size = new System.Drawing.Size(29, 17);
            this.checkBox_teslimedildi_sayi1.TabIndex = 71;
            this.checkBox_teslimedildi_sayi1.Text = " ";
            this.checkBox_teslimedildi_sayi1.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(269, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 25);
            this.label4.TabIndex = 70;
            this.label4.Text = "Dergiler";
            // 
            // tumunu_teslim_et
            // 
            this.tumunu_teslim_et.Location = new System.Drawing.Point(21, 225);
            this.tumunu_teslim_et.Name = "tumunu_teslim_et";
            this.tumunu_teslim_et.Size = new System.Drawing.Size(253, 48);
            this.tumunu_teslim_et.TabIndex = 111;
            this.tumunu_teslim_et.Text = "Seçili Dergilerin Tümünü Teslim Et";
            this.tumunu_teslim_et.UseVisualStyleBackColor = true;
            this.tumunu_teslim_et.Click += new System.EventHandler(this.tumunu_teslim_et_Click);
            // 
            // tumunu_ode
            // 
            this.tumunu_ode.Location = new System.Drawing.Point(21, 279);
            this.tumunu_ode.Name = "tumunu_ode";
            this.tumunu_ode.Size = new System.Drawing.Size(253, 45);
            this.tumunu_ode.TabIndex = 112;
            this.tumunu_ode.Text = "Seçili Dergilerin Tümü Öde";
            this.tumunu_ode.UseVisualStyleBackColor = true;
            this.tumunu_ode.Click += new System.EventHandler(this.tumunu_ode_Click);
            // 
            // btn_tamamla
            // 
            this.btn_tamamla.BackColor = System.Drawing.Color.PaleVioletRed;
            this.btn_tamamla.Font = new System.Drawing.Font("Impact", 14F);
            this.btn_tamamla.Location = new System.Drawing.Point(342, 225);
            this.btn_tamamla.Name = "btn_tamamla";
            this.btn_tamamla.Size = new System.Drawing.Size(253, 99);
            this.btn_tamamla.TabIndex = 113;
            this.btn_tamamla.Text = "D e ğ i ş i k l i k l e r i\nT a m a m l a";
            this.btn_tamamla.UseVisualStyleBackColor = false;
            this.btn_tamamla.Click += new System.EventHandler(this.btn_tamamla_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(540, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(26, 13);
            this.label1.TabIndex = 115;
            this.label1.Text = "fiyat";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(440, 47);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 13);
            this.label2.TabIndex = 114;
            this.label2.Text = "kactane";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button1.Cursor = System.Windows.Forms.Cursors.No;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button1.Location = new System.Drawing.Point(583, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(46, 41);
            this.button1.TabIndex = 116;
            this.button1.Text = "X";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // abone_edit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(628, 351);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btn_tamamla);
            this.Controls.Add(this.tumunu_ode);
            this.Controls.Add(this.tumunu_teslim_et);
            this.Controls.Add(this.label_sayi6);
            this.Controls.Add(this.label_sayi5);
            this.Controls.Add(this.label_sayi4);
            this.Controls.Add(this.label_sayi3);
            this.Controls.Add(this.label_sayi2);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label_sayi1);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.checkBox_odendi_sayi6);
            this.Controls.Add(this.txt_fiyat_sayi6);
            this.Controls.Add(this.txt_miktar_sayi6);
            this.Controls.Add(this.checkBox_teslimedildi_sayi6);
            this.Controls.Add(this.checkBox_odendi_sayi5);
            this.Controls.Add(this.txt_fiyat_sayi5);
            this.Controls.Add(this.txt_miktar_sayi5);
            this.Controls.Add(this.checkBox_teslimedildi_sayi5);
            this.Controls.Add(this.checkBox_odendi_sayi4);
            this.Controls.Add(this.txt_fiyat_sayi4);
            this.Controls.Add(this.txt_miktar_sayi4);
            this.Controls.Add(this.checkBox_teslimedildi_sayi4);
            this.Controls.Add(this.checkBox_odendi_sayi3);
            this.Controls.Add(this.txt_fiyat_sayi3);
            this.Controls.Add(this.txt_miktar_sayi3);
            this.Controls.Add(this.checkBox_teslimedildi_sayi3);
            this.Controls.Add(this.checkBox_odendi_sayi2);
            this.Controls.Add(this.txt_fiyat_sayi2);
            this.Controls.Add(this.txt_miktar_sayi2);
            this.Controls.Add(this.checkBox_teslimedildi_sayi2);
            this.Controls.Add(this.checkBox_odendi_sayi1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txt_fiyat_sayi1);
            this.Controls.Add(this.txt_miktar_sayi1);
            this.Controls.Add(this.checkBox_teslimedildi_sayi1);
            this.Controls.Add(this.label4);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "abone_edit";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "abone_edit";
            this.Load += new System.EventHandler(this.abone_edit_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label_sayi6;
        private System.Windows.Forms.Label label_sayi5;
        private System.Windows.Forms.Label label_sayi4;
        private System.Windows.Forms.Label label_sayi3;
        private System.Windows.Forms.Label label_sayi2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label_sayi1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.CheckBox checkBox_odendi_sayi6;
        private System.Windows.Forms.TextBox txt_fiyat_sayi6;
        private System.Windows.Forms.TextBox txt_miktar_sayi6;
        private System.Windows.Forms.CheckBox checkBox_teslimedildi_sayi6;
        private System.Windows.Forms.CheckBox checkBox_odendi_sayi5;
        private System.Windows.Forms.TextBox txt_fiyat_sayi5;
        private System.Windows.Forms.TextBox txt_miktar_sayi5;
        private System.Windows.Forms.CheckBox checkBox_teslimedildi_sayi5;
        private System.Windows.Forms.CheckBox checkBox_odendi_sayi4;
        private System.Windows.Forms.TextBox txt_fiyat_sayi4;
        private System.Windows.Forms.TextBox txt_miktar_sayi4;
        private System.Windows.Forms.CheckBox checkBox_teslimedildi_sayi4;
        private System.Windows.Forms.CheckBox checkBox_odendi_sayi3;
        private System.Windows.Forms.TextBox txt_fiyat_sayi3;
        private System.Windows.Forms.TextBox txt_miktar_sayi3;
        private System.Windows.Forms.CheckBox checkBox_teslimedildi_sayi3;
        private System.Windows.Forms.CheckBox checkBox_odendi_sayi2;
        private System.Windows.Forms.TextBox txt_fiyat_sayi2;
        private System.Windows.Forms.TextBox txt_miktar_sayi2;
        private System.Windows.Forms.CheckBox checkBox_teslimedildi_sayi2;
        private System.Windows.Forms.CheckBox checkBox_odendi_sayi1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_fiyat_sayi1;
        private System.Windows.Forms.TextBox txt_miktar_sayi1;
        private System.Windows.Forms.CheckBox checkBox_teslimedildi_sayi1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button tumunu_teslim_et;
        private System.Windows.Forms.Button tumunu_ode;
        private System.Windows.Forms.Button btn_tamamla;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace abone_takip2.info
{
  public  class abone_yap
    {

        public int kisi_id;
        public string dergi_isim;
        public int kac_tane;
        public bool teslim_edildi;
        public int fiyat;
        public bool odendi;
        public string satis_yapan;
        public string dergi_yil;

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace abone_takip2.info
{
    public static class kisi_boss
    {

        public static int id;
        public static int il_id;
        public static string tc;
        public static string isim;
        public static string il;
        public static string adress;
        public static bool isboss;
        public static string parola;

    }
}

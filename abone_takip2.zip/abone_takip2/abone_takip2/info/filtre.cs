﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace abone_takip2.info
{
   public class filtre
    {

        public string tc;
        public string isim;
        public string il;
        public string telefon;
        public DateTime abone_oldugu_zaman;
    }
}
